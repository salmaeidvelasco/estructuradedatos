#include "stdAfx.h"
#include "Dato.h"