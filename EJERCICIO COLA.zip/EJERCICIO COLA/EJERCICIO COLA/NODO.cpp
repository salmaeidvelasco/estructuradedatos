#include "StdAfx.h"
#include "NODO.h"


NODO::NODO(void)
{
	numero_proceso=0;
	nombre_proceso="";

}
string NODO::Get_nombre_proceso()
{
	return nombre_proceso;
}
int NODO::Get_numero_proceso()
{
	return numero_proceso;
}
void NODO::Set_nombre_proceso(string nom)
{

	nombre_proceso=nom;
}
void NODO::Set_numero_proceso(int num)
{
	numero_proceso=num;
}
bool NODO::Mayor_nombre(NODO nodito)
{
	if(Get_nombre_proceso()>nodito.Get_nombre_proceso()) {return true;}
	else{return false;}

}
bool NODO::Igual_nombre(NODO nodito)
{if(Get_nombre_proceso()==nodito.Get_nombre_proceso()) {return true;}
	else{return false;}}
bool NODO::Mayor_numero(NODO nodito)
{
   if(Get_numero_proceso()>nodito.Get_numero_proceso()) {return true;}
	else{return false;}

}
bool NODO::Igual_numero(NODO nodito)
{
	
	if(Get_numero_proceso()==nodito.Get_numero_proceso()) {return true;}
	else{return false;}

}