#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "COLA.h"
using namespace System::Windows::Forms;
using namespace std;
using namespace msclr::interop;
using namespace std;
class OPERACIONES:public COLA
{

public:
	OPERACIONES(void);
	void Guardar_cola_grilla(DataGridView^  grilla_cola);
	void Guardar_grilla_cola(DataGridView^  grilla_cola);
	int Longitud_cola();
	void Eliminar_numero_pares();
	void Eliminar_repetidos();
};

