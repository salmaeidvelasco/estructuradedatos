#include "StdAfx.h"
#include "Vector.h"
using namespace std;

Vector::Vector(void)
{ V[N]=0;
tamano=0;
}
void Vector::set_V(int elemento, int pos)
{ V[pos]= elemento;
}
	void Vector::set_tamano(int tam)
	{ tamano=tam;
	}
	int Vector::get_V(int pos)
	{ return V[pos];
	}
	int Vector::get_tamano()
	{ return tamano;
	}
	Vector Vector::concatenar (Vector vec1, Vector vec2)
	{  Vector vec3; //creo este vector porque este va a ser el concatenado de vec1 y vec2
	   vec3.tamano = vec1.tamano+vec2.tamano; //no pongo set y get despu�s del punto porque no estoy trabajando en el form1.h
	   for (int k=0; k<vec1.tamano;k++)
	   { vec3.V[k]=vec1.V[k]; //Estoy pasandole los vectores de vec1 a vec3
	   }
	   for (int i=vec1.tamano /*empiezo en lo �ltimo que me qued�*/; i<vec3.tamano;i++)
	   {vec3.V[i]=vec2.V[i-vec1.tamano]; //aqu� menos el tamano del vector 1 porque debo recorrer el vector 2 desde 0, tambi�n podr�a hacer otros for, para comenzar el vec2 [0];
	   }

	   //Ahora los voy a ordenar para mostrarlos
  int aux;
  for (int k=0; k<vec3.tamano;k++)
  { for (int t=k+1; t<vec3.tamano;t++)
   {  if (vec3.V[t]< vec3.V[k]);
      {aux = vec3.V[k];
	   vec3.V[k]= vec3.V[t];
	   vec3.V[t]=aux;
      }
   }
  }

 return vec3; //Debo enviar un vector porque estoy en vez de int o float Vector(la clase) y este va a devolver un vector
	}