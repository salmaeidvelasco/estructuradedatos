#pragma once
#include "iostream"
#define N 50
using namespace std;
class Vector
{
private:
	int V[N], tamano;
public:
	Vector(void);
	void set_V(int elemento, int pos);
	void set_tamano(int tam);
	int get_V(int pos);
	int get_tamano();
	Vector concatenar (Vector vec1, Vector vec2); //aqu� estoy creando un m�todo donde env�o dos objetos vec1 y vec2 ya ambos heredan todo de la clase madre Vector
};

