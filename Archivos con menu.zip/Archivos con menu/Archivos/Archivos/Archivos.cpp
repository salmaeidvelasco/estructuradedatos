// Archivos.cpp : main project file.

#include "stdafx.h"
//Archivos permite trabjar con estructuras heterogeneas

#include "StdAfx.h"
#include <iostream>
#include <fstream>
#include <conio.h>
#include "ABMamigo.cpp"

using namespace std;


void main() 
{int opc;
	do
	{
		cout<< "Ingrese una opcion: ";
		cin>> opc;
	ABMamigo *amig = new ABMamigo("amigOO.dat"); //amig00.dat es un nuevo archivo que aparece en mis documents
	switch (opc)
	{
	case 1:
	amig->adicionarNuevo();
	break;
	case 2:
	amig->listar();
	break;
	case 3:
	amig->buscarReg();
	break;
	case 4:
	amig->eliminarReg();
	break;
	case 5:
	amig->modificarReg();
	break;
	case 6:
	amig->listar();
	break;
	}
	
	}while (opc<0 || opc>6);
	getch();
	
}

