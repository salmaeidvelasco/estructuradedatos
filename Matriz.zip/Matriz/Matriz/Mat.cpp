#include "StdAfx.h"
#include "Mat.h"


Mat::Mat(void)
{ col=0;
 fil=0;
 Matriz[a][b]=0;
}
int Mat::Get_fil()
{ return fil;
}
void Mat::Set_fil(int f)
    { fil=f;
	}
int Mat::Get_col()
	{ return col;
	}
void Mat::Set_col(int c)
	{ col=c;
	}
int Mat::Get_Matriz(int posf, int posc)
	{ return Matriz[posf][posc];
	}
void Mat::Set_Matriz(int posf, int posc, int ele)
	{ Matriz[posf][posc]=ele;
	}