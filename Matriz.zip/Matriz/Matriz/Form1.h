#pragma once
#include "Mat.h"


namespace Matriz {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	Mat mat1;
	int posf=0;
	int posc=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  button1;
	protected: 
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::TextBox^  txtfila;
	private: System::Windows::Forms::TextBox^  txtcolumna;
	private: System::Windows::Forms::TextBox^  txtelemento;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::DataGridView^  grilla;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->txtfila = (gcnew System::Windows::Forms::TextBox());
			this->txtcolumna = (gcnew System::Windows::Forms::TextBox());
			this->txtelemento = (gcnew System::Windows::Forms::TextBox());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->grilla = (gcnew System::Windows::Forms::DataGridView());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->BeginInit();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(238, 73);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 0;
			this->button1->Text = L"Definir";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(238, 12);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 23);
			this->button2->TabIndex = 1;
			this->button2->Text = L"Definir";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// txtfila
			// 
			this->txtfila->Location = System::Drawing::Point(91, 12);
			this->txtfila->Name = L"txtfila";
			this->txtfila->Size = System::Drawing::Size(100, 20);
			this->txtfila->TabIndex = 2;
			// 
			// txtcolumna
			// 
			this->txtcolumna->Location = System::Drawing::Point(91, 73);
			this->txtcolumna->Name = L"txtcolumna";
			this->txtcolumna->Size = System::Drawing::Size(100, 20);
			this->txtcolumna->TabIndex = 3;
			// 
			// txtelemento
			// 
			this->txtelemento->Location = System::Drawing::Point(91, 132);
			this->txtelemento->Name = L"txtelemento";
			this->txtelemento->Size = System::Drawing::Size(100, 20);
			this->txtelemento->TabIndex = 5;
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(238, 132);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 23);
			this->button3->TabIndex = 4;
			this->button3->Text = L"Ingresar";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// grilla
			// 
			this->grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla->Location = System::Drawing::Point(44, 180);
			this->grilla->Name = L"grilla";
			this->grilla->Size = System::Drawing::Size(190, 113);
			this->grilla->TabIndex = 6;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(19, 14);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(23, 13);
			this->label1->TabIndex = 7;
			this->label1->Text = L"Fila";
			this->label1->Click += gcnew System::EventHandler(this, &Form1::label1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(19, 78);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(48, 13);
			this->label2->TabIndex = 8;
			this->label2->Text = L"Columna";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(19, 142);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(51, 13);
			this->label3->TabIndex = 9;
			this->label3->Text = L"Elemento";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(325, 305);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->grilla);
			this->Controls->Add(this->txtelemento);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->txtcolumna);
			this->Controls->Add(this->txtfila);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) 
		 { int fila;
		 fila=System::Convert::ToInt32(txtfila->Text);
		 mat1.Set_fil(fila);
		 grilla->RowCount=fila;

		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e)
		 {int columna;
		 columna=System::Convert::ToInt32(txtcolumna->Text);
		 mat1.Set_col(columna);
		 grilla->ColumnCount=columna;
		 }

private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e)
		 {int ele;
		 ele=System::Convert::ToInt32(txtelemento->Text);
		 mat1.Set_Matriz(posf,posc,ele);
		 grilla->Rows[posf]->Cells[posc]->Value=ele;
		 posf++;
		 posc++;
		 }
};
}

