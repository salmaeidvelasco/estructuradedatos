#pragma once
class proyecto

{
private:
	int opc;
public:
	proyecto(void);
	void menu(int op);
};

