#pragma once

namespace Proyectoform {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txt1;
	protected: 

	protected: 
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Button^  btnin;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::Label^  label12;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txt1 = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->btnin = (gcnew System::Windows::Forms::Button());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// txt1
			// 
			this->txt1->Location = System::Drawing::Point(163, 321);
			this->txt1->Name = L"txt1";
			this->txt1->Size = System::Drawing::Size(100, 20);
			this->txt1->TabIndex = 0;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(278, 28);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(45, 13);
			this->label1->TabIndex = 1;
			this->label1->Text = L"ChatBot";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(42, 54);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(95, 13);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Que desea hacer\?\r\n";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(42, 100);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(199, 13);
			this->label3->TabIndex = 3;
			this->label3->Text = L"1. Estadisticas del coronavirus en Bolivia";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(42, 132);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(113, 13);
			this->label4->TabIndex = 4;
			this->label4->Text = L"2. Registras sintomas\?";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(42, 165);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(145, 13);
			this->label5->TabIndex = 5;
			this->label5->Text = L"3. Centros de salud cercanos";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(42, 193);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(136, 13);
			this->label6->TabIndex = 6;
			this->label6->Text = L"4. Farmacias mas cercanas";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(42, 230);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(69, 13);
			this->label7->TabIndex = 7;
			this->label7->Text = L"5. Call center";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(42, 263);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(165, 13);
			this->label8->TabIndex = 8;
			this->label8->Text = L"6. Link pagina oficial del gobierno";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(42, 321);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(94, 13);
			this->label9->TabIndex = 9;
			this->label9->Text = L"Ingrese su opcion:";
			// 
			// btnin
			// 
			this->btnin->Location = System::Drawing::Point(317, 321);
			this->btnin->Name = L"btnin";
			this->btnin->Size = System::Drawing::Size(75, 23);
			this->btnin->TabIndex = 10;
			this->btnin->Text = L"Ingresar";
			this->btnin->UseVisualStyleBackColor = true;
			this->btnin->Click += gcnew System::EventHandler(this, &Form1::btnin_Click);
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(314, 100);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(62, 13);
			this->label10->TabIndex = 11;
			this->label10->Text = L"7. Consejos";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(314, 132);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(90, 13);
			this->label11->TabIndex = 12;
			this->label11->Text = L"8. Mitos comunes";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Location = System::Drawing::Point(314, 165);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(128, 13);
			this->label12->TabIndex = 13;
			this->label12->Text = L"9. Que es el coronavirus\?";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(597, 444);
			this->Controls->Add(this->label12);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->btnin);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txt1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void btnin_Click(System::Object^  sender, System::EventArgs^  e) {
			 int x;
			 x=Convert::ToInt32(txt1->Text);
			 switch (x)
			 {
				 case 1:
		 MessageBox::Show("Estadisticas actualizadas..."); break;
	 case 2:
		 MessageBox::Show("Escribenos tus sintomas para que te podamos ayudar"); break;
	 case 3:
		 MessageBox::Show("Aqui estan ubicadados los centros de salud mas cercanos"); break;
	 case 4:
		  MessageBox::Show("Aqui estan ubicadas las farmacias mas cercanas"); break;
	 case 5:
		 MessageBox::Show("LLama a este numero para que seas atendido lo mas pronto posible"); break;
	 case 6:
		 MessageBox::Show("Visita la pagina del gobierno"); break;
	 case 7:
		 MessageBox::Show("Toma unos consejos para evitar el contagio  del coronavirus..."); break;
	 case 8:
		 MessageBox::Show("No te dejes de enga�ar por falsas noticias"); break;
	 case 9:
		 MessageBox::Show("Informate sobre el coronavirus"); break;
			 }

		 }
};
}

