#include "StdAfx.h"
#include "proyecto.h"


proyecto::proyecto(void)
{
}
void proyecto::menu(int op)
{
}