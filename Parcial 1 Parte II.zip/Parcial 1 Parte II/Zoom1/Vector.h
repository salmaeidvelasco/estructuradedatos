#pragma once
#define n 50
 class Vector
{
private:
	double v[n];
	int tamano;
public:
	Vector(void);
	void Set_tamano(int tam);
	void Set_v(int pos, double elemento);
	int Get_tamano();
	int Get_v(int pos);
	Vector Calcular(Vector v1);
};

