#pragma once
#include "Vector.h"


namespace Zoom1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	Vector v1;
	Vector prom;
	int pos=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btncalcular;
	protected: 
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::DataGridView^  grillaB;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn1;
	private: System::Windows::Forms::DataGridView^  grillaA;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Button^  btningresarA;
	private: System::Windows::Forms::Button^  btndefinirA;
	private: System::Windows::Forms::TextBox^  txtelemento;
	private: System::Windows::Forms::TextBox^  txttamano;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btncalcular = (gcnew System::Windows::Forms::Button());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->grillaB = (gcnew System::Windows::Forms::DataGridView());
			this->dataGridViewTextBoxColumn1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->grillaA = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btningresarA = (gcnew System::Windows::Forms::Button());
			this->btndefinirA = (gcnew System::Windows::Forms::Button());
			this->txtelemento = (gcnew System::Windows::Forms::TextBox());
			this->txttamano = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaB))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaA))->BeginInit();
			this->SuspendLayout();
			// 
			// btncalcular
			// 
			this->btncalcular->Location = System::Drawing::Point(386, 133);
			this->btncalcular->Name = L"btncalcular";
			this->btncalcular->Size = System::Drawing::Size(75, 23);
			this->btncalcular->TabIndex = 40;
			this->btncalcular->Text = L"Calcular";
			this->btncalcular->UseVisualStyleBackColor = true;
			this->btncalcular->Click += gcnew System::EventHandler(this, &Form1::btncalcular_Click);
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(243, -47);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(14, 13);
			this->label10->TabIndex = 34;
			this->label10->Text = L"B";
			// 
			// grillaB
			// 
			this->grillaB->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grillaB->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->dataGridViewTextBoxColumn1});
			this->grillaB->Location = System::Drawing::Point(383, 177);
			this->grillaB->Name = L"grillaB";
			this->grillaB->Size = System::Drawing::Size(172, 147);
			this->grillaB->TabIndex = 33;
			// 
			// dataGridViewTextBoxColumn1
			// 
			this->dataGridViewTextBoxColumn1->HeaderText = L"Promedios";
			this->dataGridViewTextBoxColumn1->Name = L"dataGridViewTextBoxColumn1";
			// 
			// grillaA
			// 
			this->grillaA->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grillaA->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grillaA->Location = System::Drawing::Point(90, 177);
			this->grillaA->Name = L"grillaA";
			this->grillaA->Size = System::Drawing::Size(172, 147);
			this->grillaA->TabIndex = 32;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"N�meros";
			this->Column1->Name = L"Column1";
			// 
			// btningresarA
			// 
			this->btningresarA->Location = System::Drawing::Point(102, 133);
			this->btningresarA->Name = L"btningresarA";
			this->btningresarA->Size = System::Drawing::Size(75, 23);
			this->btningresarA->TabIndex = 31;
			this->btningresarA->Text = L"Ingresar";
			this->btningresarA->UseVisualStyleBackColor = true;
			this->btningresarA->Click += gcnew System::EventHandler(this, &Form1::btningresarA_Click);
			// 
			// btndefinirA
			// 
			this->btndefinirA->Location = System::Drawing::Point(102, 55);
			this->btndefinirA->Name = L"btndefinirA";
			this->btndefinirA->Size = System::Drawing::Size(75, 23);
			this->btndefinirA->TabIndex = 30;
			this->btndefinirA->Text = L"Definir";
			this->btndefinirA->UseVisualStyleBackColor = true;
			this->btndefinirA->Click += gcnew System::EventHandler(this, &Form1::btndefinirA_Click);
			// 
			// txtelemento
			// 
			this->txtelemento->Location = System::Drawing::Point(147, 94);
			this->txtelemento->Name = L"txtelemento";
			this->txtelemento->Size = System::Drawing::Size(99, 20);
			this->txtelemento->TabIndex = 29;
			// 
			// txttamano
			// 
			this->txttamano->Location = System::Drawing::Point(147, 17);
			this->txttamano->Name = L"txttamano";
			this->txttamano->Size = System::Drawing::Size(99, 20);
			this->txttamano->TabIndex = 28;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(-84, 81);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(51, 13);
			this->label3->TabIndex = 27;
			this->label3->Text = L"Elemento";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(-84, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(46, 13);
			this->label2->TabIndex = 26;
			this->label2->Text = L"Tama�o";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(-36, -47);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(14, 13);
			this->label1->TabIndex = 25;
			this->label1->Text = L"A";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(33, 28);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(46, 13);
			this->label4->TabIndex = 41;
			this->label4->Text = L"Tama�o";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(33, 97);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(56, 13);
			this->label5->TabIndex = 42;
			this->label5->Text = L"Elementos";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(676, 365);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->btncalcular);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->grillaB);
			this->Controls->Add(this->grillaA);
			this->Controls->Add(this->btningresarA);
			this->Controls->Add(this->btndefinirA);
			this->Controls->Add(this->txtelemento);
			this->Controls->Add(this->txttamano);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaB))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaA))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btndefinirA_Click(System::Object^  sender, System::EventArgs^  e) 
			 { int tam;
			  tam=System::Convert::ToInt32(txttamano->Text);
			  if(tam<=0)
			  {MessageBox::Show("Dato incorrecto");}
			  else
			  {v1.Set_tamano(tam);
			  grillaA->RowCount=tam;
			  }
			  
			 }
private: System::Void btningresarA_Click(System::Object^  sender, System::EventArgs^  e) 
		 { double ele;
		  ele = System::Convert::ToDouble(txtelemento->Text);
		  v1.Set_v(pos, ele);
		  grillaA->Rows[pos]->Cells[0]->Value=ele;
		  pos++;
		 }
private: System::Void btncalcular_Click(System::Object^  sender, System::EventArgs^  e) 
		 {  prom=prom.Calcular(v1);
		    int tamB=(v1.Get_tamano()-2);
			grillaB->RowCount=tamB;
			for(int k=0;k<tamB;k++)
			{ grillaB->Rows[k]->Cells[0]->Value= System::Convert::ToDouble(prom.Get_v(k));

			}
			
		 }
};
}



