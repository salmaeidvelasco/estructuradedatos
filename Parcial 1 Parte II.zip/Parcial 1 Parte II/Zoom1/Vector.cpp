#include "StdAfx.h"
#include "Vector.h"


Vector::Vector(void)
{ v[n]=0;
  tamano=0;
}
void Vector::Set_tamano(int tam)
{ tamano=tam;
}
	void Vector::Set_v(int pos, double elemento)
	{ v[pos]= elemento;
	}
	int Vector::Get_tamano()
	{ return tamano;
	}
	int Vector::Get_v(int pos)
	{ return v[pos];
	}
	Vector Vector::Calcular(Vector v1)
	{ Vector prom;

	for (int k=0;k<v1.tamano;k++)
	{ 
	 prom.v[k]= (v1.v[k]+v1.v[k+1]+v1.v[k+2])/3;
	
	
	}

	return prom;
	}



	