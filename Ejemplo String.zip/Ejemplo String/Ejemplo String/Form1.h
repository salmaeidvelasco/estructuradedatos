#pragma once
#include "stdafx.h"
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "FuncionesString.h"

namespace EjemploString {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;

	FuncionesString FS1;
	FuncionesString FS2;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtNombre;
	protected: 
	private: System::Windows::Forms::Button^  btnNombre;
	private: System::Windows::Forms::TextBox^  txtLong;

	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtVar1;
	private: System::Windows::Forms::Button^  btnVar1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtComparar;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtVocales;
	private: System::Windows::Forms::TextBox^  txtPosSub;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  txtSubs;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Button^  btnInter;
	private: System::Windows::Forms::Label^  label8;

	private: System::Windows::Forms::Button^  btnEncon;
	private: System::Windows::Forms::TextBox^  txtEncon;













	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtNombre = (gcnew System::Windows::Forms::TextBox());
			this->btnNombre = (gcnew System::Windows::Forms::Button());
			this->txtLong = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtVar1 = (gcnew System::Windows::Forms::TextBox());
			this->btnVar1 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtComparar = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtVocales = (gcnew System::Windows::Forms::TextBox());
			this->txtPosSub = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->txtSubs = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->btnInter = (gcnew System::Windows::Forms::Button());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->btnEncon = (gcnew System::Windows::Forms::Button());
			this->txtEncon = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// txtNombre
			// 
			this->txtNombre->Location = System::Drawing::Point(22, 21);
			this->txtNombre->Name = L"txtNombre";
			this->txtNombre->Size = System::Drawing::Size(133, 20);
			this->txtNombre->TabIndex = 0;
			// 
			// btnNombre
			// 
			this->btnNombre->Location = System::Drawing::Point(180, 19);
			this->btnNombre->Name = L"btnNombre";
			this->btnNombre->Size = System::Drawing::Size(75, 23);
			this->btnNombre->TabIndex = 1;
			this->btnNombre->Text = L"Ingresar";
			this->btnNombre->UseVisualStyleBackColor = true;
			this->btnNombre->Click += gcnew System::EventHandler(this, &Form1::btnNombre_Click);
			// 
			// txtLong
			// 
			this->txtLong->Location = System::Drawing::Point(95, 62);
			this->txtLong->Name = L"txtLong";
			this->txtLong->Size = System::Drawing::Size(84, 20);
			this->txtLong->TabIndex = 2;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(41, 65);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(48, 13);
			this->label1->TabIndex = 3;
			this->label1->Text = L"Longitud";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(29, 98);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(95, 13);
			this->label2->TabIndex = 4;
			this->label2->Text = L"Redigite el nombre";
			// 
			// txtVar1
			// 
			this->txtVar1->Location = System::Drawing::Point(22, 114);
			this->txtVar1->Name = L"txtVar1";
			this->txtVar1->Size = System::Drawing::Size(133, 20);
			this->txtVar1->TabIndex = 5;
			// 
			// btnVar1
			// 
			this->btnVar1->Location = System::Drawing::Point(180, 112);
			this->btnVar1->Name = L"btnVar1";
			this->btnVar1->Size = System::Drawing::Size(75, 23);
			this->btnVar1->TabIndex = 6;
			this->btnVar1->Text = L"Ingresar";
			this->btnVar1->UseVisualStyleBackColor = true;
			this->btnVar1->Click += gcnew System::EventHandler(this, &Form1::btnVar1_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(29, 151);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(130, 13);
			this->label3->TabIndex = 7;
			this->label3->Text = L"Las cadenas son iguales\?";
			// 
			// txtComparar
			// 
			this->txtComparar->Location = System::Drawing::Point(165, 148);
			this->txtComparar->Name = L"txtComparar";
			this->txtComparar->Size = System::Drawing::Size(62, 20);
			this->txtComparar->TabIndex = 8;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(316, 24);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(45, 13);
			this->label4->TabIndex = 9;
			this->label4->Text = L"Vocales";
			// 
			// txtVocales
			// 
			this->txtVocales->Location = System::Drawing::Point(378, 21);
			this->txtVocales->Name = L"txtVocales";
			this->txtVocales->Size = System::Drawing::Size(61, 20);
			this->txtVocales->TabIndex = 10;
			// 
			// txtPosSub
			// 
			this->txtPosSub->Location = System::Drawing::Point(378, 83);
			this->txtPosSub->Name = L"txtPosSub";
			this->txtPosSub->Size = System::Drawing::Size(61, 20);
			this->txtPosSub->TabIndex = 11;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(353, 141);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 12;
			this->button1->Text = L"Substraer";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(363, 62);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(46, 13);
			this->label5->TabIndex = 13;
			this->label5->Text = L"Sustraer";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(326, 86);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(46, 13);
			this->label6->TabIndex = 14;
			this->label6->Text = L"posicion";
			// 
			// txtSubs
			// 
			this->txtSubs->Location = System::Drawing::Point(339, 112);
			this->txtSubs->Name = L"txtSubs";
			this->txtSubs->Size = System::Drawing::Size(100, 20);
			this->txtSubs->TabIndex = 15;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(54, 5);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(44, 13);
			this->label7->TabIndex = 16;
			this->label7->Text = L"Nombre";
			// 
			// btnInter
			// 
			this->btnInter->Location = System::Drawing::Point(67, 194);
			this->btnInter->Name = L"btnInter";
			this->btnInter->Size = System::Drawing::Size(75, 23);
			this->btnInter->TabIndex = 17;
			this->btnInter->Text = L"Intercambiar";
			this->btnInter->UseVisualStyleBackColor = true;
			this->btnInter->Click += gcnew System::EventHandler(this, &Form1::btnInter_Click);
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(531, 24);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(85, 13);
			this->label8->TabIndex = 18;
			this->label8->Text = L"Encontrar letra a";
			// 
			// btnEncon
			// 
			this->btnEncon->Location = System::Drawing::Point(548, 66);
			this->btnEncon->Name = L"btnEncon";
			this->btnEncon->Size = System::Drawing::Size(68, 22);
			this->btnEncon->TabIndex = 20;
			this->btnEncon->Text = L"Encontrar";
			this->btnEncon->UseVisualStyleBackColor = true;
			this->btnEncon->Click += gcnew System::EventHandler(this, &Form1::btnEncon_Click);
			// 
			// txtEncon
			// 
			this->txtEncon->Location = System::Drawing::Point(534, 40);
			this->txtEncon->Name = L"txtEncon";
			this->txtEncon->Size = System::Drawing::Size(100, 20);
			this->txtEncon->TabIndex = 21;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(890, 261);
			this->Controls->Add(this->txtEncon);
			this->Controls->Add(this->btnEncon);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->btnInter);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->txtSubs);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->txtPosSub);
			this->Controls->Add(this->txtVocales);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txtComparar);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->btnVar1);
			this->Controls->Add(this->txtVar1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtLong);
			this->Controls->Add(this->btnNombre);
			this->Controls->Add(this->txtNombre);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnNombre_Click(System::Object^  sender, System::EventArgs^  e) {
				 int cont=0;
				 string n;
				 n=(marshal_as<std::string>(System::Convert::ToString(txtNombre->Text)));
				FS1.Set_nombre(n);
				 int l;
				 l=n.length();
				 FS1.Set_longitud(l);
				 txtLong->Text=System::Convert::ToString(l);
				 for(int i=0;i<l;i++)
				 {if(n.at(i)=='a'||n.at(i)=='e'||n.at(i)=='i'||n.at(i)=='o'||n.at(i)=='u')
				 {cont++;}
				 txtVocales->Text=System::Convert::ToString(cont);}

			 }
	
private: System::Void btnVar1_Click(System::Object^  sender, System::EventArgs^  e) {
			 string var1;
			 var1=(marshal_as<std::string>(System::Convert::ToString(txtVar1->Text)));
			 FS2.Set_nombre(var1);
			  if((FS1.Get_nombre()).compare(var1)==0)
			  {txtComparar->Text=System::Convert::ToString("Si");}
			  else
			  {txtComparar->Text=System::Convert::ToString("No");}

		 }

private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 int pos;
			 pos=System::Convert::ToInt32(txtPosSub->Text);
			 txtSubs->Text=marshal_as<System::String^>((FS1.Get_nombre()).substr(pos,FS1.Get_longitud()-pos));

		 }
private: System::Void btnInter_Click(System::Object^  sender, System::EventArgs^  e) {
			 string a,b;
			 a=FS1.Get_nombre();
			 b=FS2.Get_nombre();
			 (a).swap(b);
			 txtNombre->Text=marshal_as<System::String^>(a);
			 txtVar1->Text=marshal_as<System::String^>(b);
		 }
private: System::Void btnEncon_Click(System::Object^  sender, System::EventArgs^  e) {
			
			 for(int i=0;i<FS1.Get_longitud();i++)
			 {if((FS1.Get_nombre()).at(i)=='a'||(FS1.Get_nombre()).at(i)=='A')
			 {txtEncon->Text=System::Convert::ToString(i);}
			 else{txtEncon->Text=marshal_as<System::String^>("No existe");}
			 }
		 }

};
}

