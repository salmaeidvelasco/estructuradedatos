#include "StdAfx.h"
#include "FuncionesString.h"


FuncionesString::FuncionesString(void)
{
}
int FuncionesString::Get_longitud()
{return longitud;}

void FuncionesString::Set_longitud(int lon)
{longitud=lon;}

string FuncionesString::Get_nombre()
{return nombre;}

void FuncionesString::Set_nombre(string nom)
{nombre=nom;}
