#pragma once
# include <string>
#include <iostream>

using namespace std;

class FuncionesString
{
private:
	int longitud;
	string nombre;
public:
	FuncionesString(void);
	int Get_longitud();
	void Set_longitud(int lon);
	string Get_nombre();
	void Set_nombre(string nom);


};

