#include "StdAfx.h"
#include "Vector.h"


Vector::Vector(void)
{ V[n]=0; //Vector se llene de ceros
 tamano=0;
}
void Vector::set_V(int elemento, int pos)
{ V[pos]= elemento;
  
}
int Vector::get_V(int pos)
	{ return V[pos];
	}
void Vector::set_tamano(int tam)
	{ tamano=tam;
	}
int Vector::get_tamano()
	{ return tamano;
	}
void Vector::calcular(int tam) //Si voy retornar un vector uso void y en el button pongo con for.
    { int aux=3;
         V[0]=1;
		for (int k=1;k<tam;k++)
        { V[k]=aux;
		  aux= aux+3;
        }
	}