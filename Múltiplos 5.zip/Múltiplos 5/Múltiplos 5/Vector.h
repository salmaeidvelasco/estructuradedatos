#pragma once
#include "iostream"
#include "conio.h"
#include "math.h"
#define n 50
using namespace std;
class Vector
{
private:
	int V[n],tamano;
public:
	Vector(void);
	void set_V(int elemento, int pos);
	int get_V(int pos);
	void set_tamano(int tam);
	int get_tamano();
	void calcular(int tam);
};

