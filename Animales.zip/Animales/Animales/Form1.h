#pragma once
#include "iostream"
#include "msclr\marshal_cppstd.h"
#include "conio.h"
#include "Pez.h"
#include  "Ave.h"

namespace Animales {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}

	protected: 

	protected: 











	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  txtAbocas;

	private: System::Windows::Forms::TextBox^  txtAalas;


	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::TextBox^  txtAojos;


	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::TextBox^  txtPbocas;

	private: System::Windows::Forms::TextBox^  txtPaletas;


	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::TextBox^  txtPojos;

	private: System::Windows::Forms::Button^  btbIngresar;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->txtAbocas = (gcnew System::Windows::Forms::TextBox());
			this->txtAalas = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->txtAojos = (gcnew System::Windows::Forms::TextBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->txtPbocas = (gcnew System::Windows::Forms::TextBox());
			this->txtPaletas = (gcnew System::Windows::Forms::TextBox());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->txtPojos = (gcnew System::Windows::Forms::TextBox());
			this->btbIngresar = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(82, 188);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(37, 13);
			this->label1->TabIndex = 14;
			this->label1->Text = L"Bocas";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(186, 188);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(28, 13);
			this->label5->TabIndex = 13;
			this->label5->Text = L"Ojos";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(289, 188);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(27, 13);
			this->label6->TabIndex = 12;
			this->label6->Text = L"Alas";
			// 
			// txtAbocas
			// 
			this->txtAbocas->Location = System::Drawing::Point(68, 237);
			this->txtAbocas->Name = L"txtAbocas";
			this->txtAbocas->Size = System::Drawing::Size(65, 20);
			this->txtAbocas->TabIndex = 11;
			// 
			// txtAalas
			// 
			this->txtAalas->Location = System::Drawing::Point(277, 237);
			this->txtAalas->Name = L"txtAalas";
			this->txtAalas->Size = System::Drawing::Size(65, 20);
			this->txtAalas->TabIndex = 10;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(12, 213);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(26, 13);
			this->label7->TabIndex = 9;
			this->label7->Text = L"Ave";
			// 
			// txtAojos
			// 
			this->txtAojos->Location = System::Drawing::Point(179, 237);
			this->txtAojos->Name = L"txtAojos";
			this->txtAojos->Size = System::Drawing::Size(65, 20);
			this->txtAojos->TabIndex = 8;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(82, 351);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(37, 13);
			this->label8->TabIndex = 21;
			this->label8->Text = L"Bocas";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(186, 351);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(28, 13);
			this->label9->TabIndex = 20;
			this->label9->Text = L"Ojos";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(289, 351);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(36, 13);
			this->label10->TabIndex = 19;
			this->label10->Text = L"Aletas";
			// 
			// txtPbocas
			// 
			this->txtPbocas->Location = System::Drawing::Point(68, 400);
			this->txtPbocas->Name = L"txtPbocas";
			this->txtPbocas->Size = System::Drawing::Size(65, 20);
			this->txtPbocas->TabIndex = 18;
			// 
			// txtPaletas
			// 
			this->txtPaletas->Location = System::Drawing::Point(277, 400);
			this->txtPaletas->Name = L"txtPaletas";
			this->txtPaletas->Size = System::Drawing::Size(65, 20);
			this->txtPaletas->TabIndex = 17;
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(12, 376);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(25, 13);
			this->label11->TabIndex = 16;
			this->label11->Text = L"Pez";
			// 
			// txtPojos
			// 
			this->txtPojos->Location = System::Drawing::Point(179, 400);
			this->txtPojos->Name = L"txtPojos";
			this->txtPojos->Size = System::Drawing::Size(65, 20);
			this->txtPojos->TabIndex = 15;
			// 
			// btbIngresar
			// 
			this->btbIngresar->Location = System::Drawing::Point(128, 12);
			this->btbIngresar->Name = L"btbIngresar";
			this->btbIngresar->Size = System::Drawing::Size(126, 159);
			this->btbIngresar->TabIndex = 22;
			this->btbIngresar->Text = L"Ingresar";
			this->btbIngresar->UseVisualStyleBackColor = true;
			this->btbIngresar->Click += gcnew System::EventHandler(this, &Form1::btbIngresar_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(506, 454);
			this->Controls->Add(this->btbIngresar);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->txtPbocas);
			this->Controls->Add(this->txtPaletas);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->txtPojos);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->txtAbocas);
			this->Controls->Add(this->txtAalas);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->txtAojos);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btbIngresar_Click(System::Object^  sender, System::EventArgs^  e)
			 
			 {   Ave ave1;
			     Pez pez1;
				 ave1.Set_boca(System::Convert::ToInt32(txtAbocas->Text));
				 ave1.Set_ojos(System::Convert::ToInt32(txtAojos->Text));
				 ave1.Set_alas(System::Convert::ToInt32(txtAalas->Text));
				 pez1.Set_boca(System::Convert::ToInt32(txtPbocas->Text));
				 pez1.Set_ojos(System::Convert::ToInt32(txtPojos->Text));
				 pez1.Set_aletas(System::Convert::ToInt32(txtPaletas->Text));
				 //El bot�n igresar solo est� para registrar los datos nada m�s.
			

			 }
};
}

