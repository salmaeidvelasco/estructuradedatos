#pragma once
#define M 25
class PILA 
{
protected:
	int P[M];
	int puntero;
public:
	PILA(void);
	void Apilar(int x);
	int Desapilar();
	bool Vacio();
	bool Lleno();

};

