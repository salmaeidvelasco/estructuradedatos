#include "StdAfx.h"
#include "PILA.h"


PILA::PILA(void)
{
	puntero=-1;
}
void PILA::Apilar(int x){
P[++puntero]=x;
}
int PILA::Desapilar(){
int a=P[puntero--];
return a;
}
bool PILA::Vacio(){
if(puntero==-1)
return true;
}
bool PILA::Lleno(){
if(puntero==M-1)
return true;}
