#pragma once
#include "PILA.h"

namespace Ej1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	PILA P1;
	int pos=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::TextBox^  txtApilar;
	private: System::Windows::Forms::Button^  btnApilar;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtElem;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtApilar = (gcnew System::Windows::Forms::TextBox());
			this->btnApilar = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtElem = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(30, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(30, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"PILA";
			// 
			// txtApilar
			// 
			this->txtApilar->Location = System::Drawing::Point(43, 40);
			this->txtApilar->Name = L"txtApilar";
			this->txtApilar->Size = System::Drawing::Size(100, 20);
			this->txtApilar->TabIndex = 1;
			// 
			// btnApilar
			// 
			this->btnApilar->Location = System::Drawing::Point(165, 40);
			this->btnApilar->Name = L"btnApilar";
			this->btnApilar->Size = System::Drawing::Size(75, 23);
			this->btnApilar->TabIndex = 2;
			this->btnApilar->Text = L"Apilar";
			this->btnApilar->UseVisualStyleBackColor = true;
			this->btnApilar->Click += gcnew System::EventHandler(this, &Form1::btnApilar_Click);
			// 
			// Grid
			// 
			this->Grid->BackgroundColor = System::Drawing::SystemColors::MenuBar;
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid->GridColor = System::Drawing::SystemColors::MenuBar;
			this->Grid->Location = System::Drawing::Point(32, 79);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(142, 150);
			this->Grid->TabIndex = 3;
			this->Grid->RowCount = 25;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Pila";
			this->Column1->Name = L"Column1";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(197, 95);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 4;
			this->button1->Text = L"Desapilar";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(207, 147);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(56, 13);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Elementos";
			// 
			// txtElem
			// 
			this->txtElem->Location = System::Drawing::Point(180, 163);
			this->txtElem->Name = L"txtElem";
			this->txtElem->Size = System::Drawing::Size(100, 20);
			this->txtElem->TabIndex = 6;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->txtElem);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btnApilar);
			this->Controls->Add(this->txtApilar);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnApilar_Click(System::Object^  sender, System::EventArgs^  e) {
				 int A=Convert::ToInt32(txtApilar->Text);
				 if(P1.Lleno()==true)
					 MessageBox::Show("Pila Llena");
				 else
				 {
					 P1.Apilar(A);
					 Grid->Rows[pos++]->Cells[0]->Value=(A);
				 }
				 txtElem->Text=Convert::ToString(pos);
			 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 P1.Desapilar();
			 Grid->Rows->RemoveAt(--pos);
			 txtElem->Text=Convert::ToString(pos);
		 }
};
}

