#pragma once
#define M 25
class PILA
{
private:
	int puntero;
	int P[M];
public:
	PILA(void);
	int Get_puntero();
	void Set_puntero(int p);

	void Apilar(int a);
	int Desapilar();
	bool Lleno();
	bool Vacio();

};

