#include "StdAfx.h"
#include "Enlazadas.h"


Enlazadas::Enlazadas(void)
{ 

}
void Enlazadas::push (int elemento, Enlazadas*& H)
{
  Enlazada* NewEnlazada;
  NewEnlazada->data=ele; //En el nuevo nodo dato = ele
  NewEnlazada->next =H; //que apunte a H que es la cabeza
}