#pragma once
 class Enlazadas
{
private:
	int data; //Elemento dentro de nodo
    Enlazadas* next;

public:
	Enlazadas(void);
	void push (int elemento, Enlazadas*& H);








};

