#pragma once
#include <string>
using namespace std;
class Nodo
{
protected:
	double telefono;
	string nombre;
public:
	Nodo(void);
	void Set_telefono(double x);
	void Set_nombre( string y);
	double Get_telefono();
	string Get_nombre();
};

