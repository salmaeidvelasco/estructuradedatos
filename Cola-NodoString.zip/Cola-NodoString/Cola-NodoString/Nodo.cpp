#include "StdAfx.h"
#include "Nodo.h"
using namespace std;

Nodo::Nodo(void)
{ telefono=0;
}
void Nodo::Set_telefono(double x)
{
	telefono=x;
}
void Nodo::Set_nombre( string y)
{
	nombre=y;
}
double Nodo::Get_telefono()
{
	return telefono;
}
string Nodo::Get_nombre()
{
	return nombre;
}