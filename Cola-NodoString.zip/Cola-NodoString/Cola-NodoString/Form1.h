#pragma once
#include "Cola.h"
#include "msclr\marshal_cppstd.h"

namespace ColaNodoString {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;
	Cola cola1;
	Nodo nodo1;
	int pos=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  grilla;
	protected: 
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::Button^  btnencolar;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  txtennom;
	private: System::Windows::Forms::TextBox^  txtdesnom;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  btndesencolar;
	private: System::Windows::Forms::TextBox^  txtentel;
	private: System::Windows::Forms::TextBox^  txtdestel;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->grilla = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnencolar = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtennom = (gcnew System::Windows::Forms::TextBox());
			this->txtdesnom = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->btndesencolar = (gcnew System::Windows::Forms::Button());
			this->txtentel = (gcnew System::Windows::Forms::TextBox());
			this->txtdestel = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->BeginInit();
			this->SuspendLayout();
			// 
			// grilla
			// 
			this->grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->Column1, this->Column2});
			this->grilla->Location = System::Drawing::Point(20, 207);
			this->grilla->Name = L"grilla";
			this->grilla->Size = System::Drawing::Size(383, 140);
			this->grilla->TabIndex = 0;

			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Telefono";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Cliente";
			this->Column2->Name = L"Column2";
			// 
			// btnencolar
			// 
			this->btnencolar->Location = System::Drawing::Point(281, 17);
			this->btnencolar->Name = L"btnencolar";
			this->btnencolar->Size = System::Drawing::Size(105, 23);
			this->btnencolar->TabIndex = 1;
			this->btnencolar->Text = L"Encolar";
			this->btnencolar->UseVisualStyleBackColor = true;
			this->btnencolar->Click += gcnew System::EventHandler(this, &Form1::btnencolar_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(107, 13);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(49, 13);
			this->label1->TabIndex = 2;
			this->label1->Text = L"Telefono";
			// 
			// txtennom
			// 
			this->txtennom->Location = System::Drawing::Point(173, 41);
			this->txtennom->Name = L"txtennom";
			this->txtennom->Size = System::Drawing::Size(86, 20);
			this->txtennom->TabIndex = 3;
			// 
			// txtdesnom
			// 
			this->txtdesnom->Location = System::Drawing::Point(173, 101);
			this->txtdesnom->Name = L"txtdesnom";
			this->txtdesnom->Size = System::Drawing::Size(86, 20);
			this->txtdesnom->TabIndex = 6;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(107, 44);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(44, 13);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Nombre";
			// 
			// btndesencolar
			// 
			this->btndesencolar->Location = System::Drawing::Point(281, 83);
			this->btndesencolar->Name = L"btndesencolar";
			this->btndesencolar->Size = System::Drawing::Size(105, 23);
			this->btndesencolar->TabIndex = 4;
			this->btndesencolar->Text = L"Desencolar";
			this->btndesencolar->UseVisualStyleBackColor = true;
			// 
			// txtentel
			// 
			this->txtentel->Location = System::Drawing::Point(173, 10);
			this->txtentel->Name = L"txtentel";
			this->txtentel->Size = System::Drawing::Size(86, 20);
			this->txtentel->TabIndex = 9;
			// 
			// txtdestel
			// 
			this->txtdestel->Location = System::Drawing::Point(173, 75);
			this->txtdestel->Name = L"txtdestel";
			this->txtdestel->Size = System::Drawing::Size(86, 20);
			this->txtdestel->TabIndex = 10;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(17, 93);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(61, 13);
			this->label5->TabIndex = 11;
			this->label5->Text = L"Desencolar";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(17, 27);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(43, 13);
			this->label6->TabIndex = 12;
			this->label6->Text = L"Encolar";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(102, 106);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(44, 13);
			this->label3->TabIndex = 14;
			this->label3->Text = L"Nombre";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(102, 75);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(49, 13);
			this->label4->TabIndex = 13;
			this->label4->Text = L"Telefono";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(538, 363);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->txtdestel);
			this->Controls->Add(this->txtentel);
			this->Controls->Add(this->txtdesnom);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->btndesencolar);
			this->Controls->Add(this->txtennom);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnencolar);
			this->Controls->Add(this->grilla);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnencolar_Click(System::Object^  sender, System::EventArgs^  e)
			 {
				 grilla->RowCount=25;
				 double tel;
				 tel=System::Convert::ToDouble(txtentel->Text);
				 nodo1.Set_telefono(tel);
				 string nom;
				  nom=marshal_as<std::string>(System::Convert::ToDouble(txtentel->Text));
				  nodo1.Set_nombre(nom);
				  grilla->Rows[pos]->Cells[0]->Value=tel;
				  grilla->Rows[pos]->Cells[1]->Value=marshal_as<System::String^>(nom);
				  pos++;
			 }
};
}

