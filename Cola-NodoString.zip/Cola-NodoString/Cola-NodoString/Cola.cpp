#include "StdAfx.h"
#include "Cola.h"

using namespace std;
Cola::Cola(void)
{
	frente=0;
	final=-1;
}
void Cola::encolar(Nodo ele)
{
	col[++final]=ele;
}
Nodo Cola::desencolar()
{
	Nodo aux;
	aux=col[frente];
	frente++;
	return aux;
}
bool Cola::vacio()
{
	if(final==-1)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool Cola::lleno()
{
if(final==M-1)
	{
		return true;
	}
	else
	{
		return false;
	}
}