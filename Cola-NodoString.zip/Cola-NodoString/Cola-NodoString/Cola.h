#pragma once
#include "Nodo.h"
#define M 25
using namespace std;
 class Cola: public Nodo
{
private:
	int frente;
	int final;
	Nodo col[M];
public:
	Cola(void);
	void encolar(Nodo ele);
	Nodo desencolar();
	bool vacio();
	bool lleno();
};

