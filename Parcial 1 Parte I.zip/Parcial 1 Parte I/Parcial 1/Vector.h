#pragma once
#include <iostream>
#define n 50
using namespace std;
 class Vector

{
private:
	int v[n];
	int numero;
public:
	Vector(void);
	void Set_numero(int num);
	int Get_numero();
	void Set_v(int elemento, int pos);
	int Get_v(int pos);
	void factorial();
};

