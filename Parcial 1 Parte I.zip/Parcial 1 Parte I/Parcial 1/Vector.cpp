#include "StdAfx.h"
#include "Vector.h"


Vector::Vector(void)
{ v[n]=0;
 numero=0;
}
void Vector::Set_numero(int num)
{ numero=num;
}
int Vector::Get_numero()
{ return numero;
}
void Vector::Set_v(int elemento, int pos)
{ v[pos]= elemento;
}
int Vector::Get_v(int pos)
{ return v[pos];
}
void Vector::factorial()
{  int fac=1;
int aux=1;
	 for (int k=0; k<=numero; k++)
	 { v[k] = fac* aux;
	   fac= v[k];
	   aux++;
	 }
				
}