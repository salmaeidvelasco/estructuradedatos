#include "StdAfx.h"
#include "MAT.h"


MAT::MAT(void)
{
	filas=0;
	columnas=0;
	Matriz[M][M]=0;
}
int MAT::GetFilas(){
return filas;}
void MAT::SetFilas(int F){
filas=F;}
int MAT::GetColumnas(){
return columnas;}
void MAT::SetColumnas(int C){
columnas=C;}
int MAT::GetMatriz(int CF, int CC){
return Matriz[CF][CC];}
void MAT::SetMatriz(int CF, int CC, int a){
Matriz[CF][CC]=a;
}

void MAT::EliminarRep(){
int F=0,C=0;
int P;
do
{
	do{
	int k=0;
	int aux=Matriz[F][C];
	for(int i=0;i<GetFilas();i++)
	{
		for(int j=0;j<GetColumnas();j++)
		{
			P=Matriz[i][j];
			if(P==aux)
			{k++;
			if(k>1)
			{SetMatriz(i,j,0);}
			}
		}
	}
	C++;}while(C<GetColumnas());
	F++;
	C=0;
	}while (F<GetFilas()&&C<GetColumnas());

}
int MAT::ContMatSup(){
	int fil=0, col=0;
	int cont=0;
	int aux2;
	int cont2;
	do{
		int aux=Matriz[fil][col];
		int k=0;
		for(int i=fil+1;i<GetFilas()-1;i++)
			{
				aux2=Matriz[i][col];
				if(aux2=0)
				{k=0;}
			}
		if(k==0)
			{
				col++;
				fil=col;
			}
		cont2=k;
	}while(fil<GetFilas());
	if (cont2==0)
	{for(int i=GetColumnas()-1;i>0;i--)
	{cont=cont+i;}
	return cont;
}
}