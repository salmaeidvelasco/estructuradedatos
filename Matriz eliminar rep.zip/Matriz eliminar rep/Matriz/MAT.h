#pragma once
#define M 50
class MAT
{
private:
	int Matriz[M][M];
	int filas;
	int columnas;

public:
	MAT(void);
	int GetFilas();
	void SetFilas(int F);
	int GetColumnas();
	void SetColumnas(int C);
	int GetMatriz(int CF, int CC);
	void SetMatriz(int CF, int CC, int a);
	void EliminarRep();
	int ContMatSup();
};

