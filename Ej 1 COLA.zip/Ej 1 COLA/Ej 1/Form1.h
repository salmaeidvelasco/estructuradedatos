#pragma once
#include "Pila.h"

namespace Ej1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	Pila pila1;
	int pos=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  button1;
	protected: 
	private: System::Windows::Forms::TextBox^  txtapilar;
	private: System::Windows::Forms::DataGridView^  grilla;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::TextBox^  txtdesapilar;
	private: System::Windows::Forms::Button^  btndesapilar;
	private: System::Windows::Forms::TextBox^  txtele;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->txtapilar = (gcnew System::Windows::Forms::TextBox());
			this->grilla = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->txtdesapilar = (gcnew System::Windows::Forms::TextBox());
			this->btndesapilar = (gcnew System::Windows::Forms::Button());
			this->txtele = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->BeginInit();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(150, 12);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(83, 32);
			this->button1->TabIndex = 0;
			this->button1->Text = L"Apilar";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// txtapilar
			// 
			this->txtapilar->Location = System::Drawing::Point(12, 12);
			this->txtapilar->Name = L"txtapilar";
			this->txtapilar->Size = System::Drawing::Size(99, 20);
			this->txtapilar->TabIndex = 1;
			// 
			// grilla
			// 
			this->grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grilla->Location = System::Drawing::Point(16, 142);
			this->grilla->Name = L"grilla";
			this->grilla->Size = System::Drawing::Size(134, 180);
			this->grilla->TabIndex = 2;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"N�meros";
			this->Column1->Name = L"Column1";
			// 
			// txtdesapilar
			// 
			this->txtdesapilar->Location = System::Drawing::Point(12, 76);
			this->txtdesapilar->Name = L"txtdesapilar";
			this->txtdesapilar->Size = System::Drawing::Size(99, 20);
			this->txtdesapilar->TabIndex = 4;
			// 
			// btndesapilar
			// 
			this->btndesapilar->Location = System::Drawing::Point(150, 76);
			this->btndesapilar->Name = L"btndesapilar";
			this->btndesapilar->Size = System::Drawing::Size(83, 32);
			this->btndesapilar->TabIndex = 3;
			this->btndesapilar->Text = L"Desapilar";
			this->btndesapilar->UseVisualStyleBackColor = true;
			this->btndesapilar->Click += gcnew System::EventHandler(this, &Form1::btndesapilar_Click);
			// 
			// txtele
			// 
			this->txtele->Location = System::Drawing::Point(189, 213);
			this->txtele->Name = L"txtele";
			this->txtele->Size = System::Drawing::Size(99, 20);
			this->txtele->TabIndex = 5;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(407, 375);
			this->Controls->Add(this->txtele);
			this->Controls->Add(this->txtdesapilar);
			this->Controls->Add(this->btndesapilar);
			this->Controls->Add(this->grilla);
			this->Controls->Add(this->txtapilar);
			this->Controls->Add(this->button1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e)
			 {   if (pila1.lleno())
			 {
				 MessageBox::Show("La pila esta llena");
				
			 }
			 else
			 {
				  grilla->RowCount=a;
				 int ele;
				 ele=System::Convert::ToInt32(txtapilar->Text);
				 pila1.apilar(ele);
				 grilla->Rows[pos]->Cells[0]->Value=ele; 
				 pos++;
			 }
			 txtele->Text=System::Convert::ToString(pos);
			
			 }
private: System::Void btndesapilar_Click(System::Object^  sender, System::EventArgs^  e)
		 {
			 if(pila1.vacio())
			 {
				MessageBox::Show("La pila est� vac�a");

			 }
			 else
			 {
				  int aux;
				 aux=pila1.desapilar();
				 txtdesapilar->Text=System::Convert::ToString(aux);
				 grilla->Rows->RemoveAt(--pos);
			 }
			 txtele->Text=System::Convert::ToString(pos);
		 }
};
}

