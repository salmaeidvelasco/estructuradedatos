#pragma once
#define a 25
 class Pila
{
private:
	int cima;
	int pila[a];
public:
	Pila(void);
	void apilar(int ele);
	int desapilar();
	bool lleno();
	bool vacio();

};

