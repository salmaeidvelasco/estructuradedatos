#include "StdAfx.h"
#include "Pila.h"


Pila::Pila(void)
{
	pila[a]=0;
	cima=-1;
}
void Pila::apilar(int ele)
{
	cima++;
	pila[cima]=ele;
}
int Pila::desapilar()
{
	int aux;
	aux=pila[cima];
	cima--;
	return aux;
}
bool Pila::lleno()
{
	if (cima==a-1)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool Pila::vacio()
{
	if(cima==-1)
	{
		return true;
	}
	else
	{
		return false;
	}


}